import MenuItem, { type MenuItemProps } from '@mui/material/MenuItem';
import { type MRT_Header, type MRT_RowData, MRT_TableHeadCellFilterContainer, type MRT_TableInstance } from 'material-react-table';

export interface FilterMenuItemProps<TData extends MRT_RowData>
  extends MenuItemProps {
  header: MRT_Header<TData>;
  table: MRT_TableInstance<TData>;
}

const FilterMenuItem = <TData extends MRT_RowData>({
  header,
  table,
  ...rest
}: FilterMenuItemProps<TData>) => {

  return (
    <MenuItem
      sx={{
        alignItems: 'center',
        justifyContent: 'space-between',
        flexDirection: 'row',
        my: 0,
      }}
      {...rest}
    >
      <MRT_TableHeadCellFilterContainer
        key={header.id}
        header={header}
        table={table}
        in
        sx={{
          flexGrow: 1,
        }}
      />
    </MenuItem>
  );
};

export default FilterMenuItem;
