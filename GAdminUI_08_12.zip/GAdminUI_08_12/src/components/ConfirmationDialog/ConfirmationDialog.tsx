import { Button, Stack } from '@mui/material';
import { ConfirmationUpdateContent, FooterConfirmation, HeaderDialog } from './styled';

export const ConfirmationDialog = (props: any) => {
    const handleAction = () => {
        props.handleAction()
        return;
    };

    return (
        
        <ConfirmationUpdateContent>
            <HeaderDialog>
                <h2 className='font-bold'>{props.header}</h2>
            </HeaderDialog>
            <p>
                {props.message}
            </p>

            <FooterConfirmation>
                <Stack spacing={1} direction={'row'} justifyContent={'flex-end'}>
                    <Button onClick={() => {props.setShowConfirmationDialog(false)}}>
                        Cancel
                    </Button>
                    <Button
                        onClick={handleAction}
                    >
                        Confirm
                    </Button>
                </Stack>
            </FooterConfirmation>
        </ConfirmationUpdateContent>
    );
};
