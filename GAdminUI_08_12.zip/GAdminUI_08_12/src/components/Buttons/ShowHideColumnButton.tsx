import React, { useState } from "react";
import { type MRT_TableInstance } from "material-react-table";
import { Tooltip } from "@mui/material";
import ShowHideIcon from "../Icons/ShowHideIcon";
import GearMenuIcon from "../Icons/GearMenuIcons";
import ShowHideColumnsMenu from "../Filter/ShowHideColumnsMenu";

interface ShowHideColumnsButtonProps {
	table: MRT_TableInstance<any>;
	title: string;
}

const ShowHideColumnsButton: React.FC<ShowHideColumnsButtonProps> = ({ table, title }) => {
	const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

	const handleClick = (e: React.MouseEvent<HTMLElement>) => {
		anchorEl ? setAnchorEl(null) : setAnchorEl(e.currentTarget);
	}

	const handleClose = () => {
		setAnchorEl(null);
	}

	return (
		<>
			<button className="flex flex-grow px-4 py-2" type='button' onClick={handleClick} >
				<div className="flex justify-start content-center p-2">
					<Tooltip title={title}>
						<span className="flex flex-row">
							<GearMenuIcon>
								<ShowHideIcon />
							</GearMenuIcon>
							<p className="text-base content-center pr-10">{title}</p>
						</span>
					</Tooltip>
				</div>
				{anchorEl && (
					<ShowHideColumnsMenu
						anchorEl={anchorEl}
						open={Boolean(anchorEl)}
						table={table}
						onClose={handleClose}
					/>
				)}
			</button>
		</>
	);
}

export default ShowHideColumnsButton;
