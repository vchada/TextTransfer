import { useTable, useSortBy, usePagination, useExpanded, Column, useFilters } from 'react-table';
import { Box, Button, MenuItem, TableHead } from '@mui/material';
import { LoadingComponent } from '../LoadingComponent/LoadingComponent';
import * as Icons from '../Icons/Icons';
import { Content, PaginationTable, TableData, TableRow, TableStyled } from './styled';
import { NoDataTable } from './NoDataTable/NoDataTable';
import { SelectComponent } from '../SelectComponent/SelectComponent';

interface TableComponentProps {
  columns: Column | any;
  dataTable: any;
  isLoading: boolean;
  isSorted?: boolean;
  collapsedTable?: boolean;
}

export const TableComponent = ({
  columns,
  dataTable,
  isLoading,
  collapsedTable = false,
  isSorted = false,
}: TableComponentProps) => {
  const sortedInitialState = isSorted
    ? {
        initialState: {
          sortBy: [
            {
              id: 'updatedTimestamp',
              desc: true,
            },
          ],
        },
      }
    : null;

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,

    page,
    nextPage,
    previousPage,
    canNextPage,
    canPreviousPage,
    pageOptions,
    gotoPage,
    pageCount,
    setPageSize,
    state: { pageIndex, pageSize },

    prepareRow,
  } = useTable(
    {
      columns: columns,
      data: dataTable,
      ...sortedInitialState,
    },
    useFilters,
    useSortBy,
    useExpanded,
    usePagination,
    
  );

  const dataShowPostsPerPage = [10, 50, 100];

  return (
    <>
      <Content>
        {isLoading && <LoadingComponent />}

        <TableStyled {...getTableProps()}>
          <TableHead>
            {headerGroups.map((headerGroup) => (
              <tr {...headerGroup.getHeaderGroupProps()}>
                {headerGroup.headers.map((column) => (
                  <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                    {column.Header !== 'Edit' ? (
                      <div className="content_th" title={''}>
                        {column.render('Header')}
                        {column.isSorted ? (
                          column.isSortedDesc ? (
                            <Icons.ArrowDropDownIcon />
                          ) : (
                            <Icons.ArrowDropUpIcon />
                          )
                        ) : (
                          <div className="space_th">
                            <Icons.ArrowDropUpIcon />
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>{column.render('Header')}</div>
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </TableHead>

          <tbody {...getTableBodyProps()}>
            {dataTable.length > 0 ? (
              page.map((row) => {
                prepareRow(row);
                return (
                  <TableRow
                    {...row.getRowProps()}
                    onClick={() => collapsedTable && row.toggleRowExpanded()}
                  >
                    {row.cells.map((cell) => {
                      return (
                        <TableData {...cell.getCellProps()}>
                          {cell.render('Cell')}
                        </TableData>
                      );
                    })}
                  </TableRow>
                );
              })
            ) : (
              <NoDataTable />
            )}
          </tbody>
        </TableStyled>
      </Content>

      <PaginationTable>
        <div className="pagination-part">
          <Box>
            <SelectComponent
              variant="outlined"
              size="small"
              value={pageSize}
              onChange={(e: any) => setPageSize(Number(e.target.value))}
            >
              {dataShowPostsPerPage.map((pageSize) => (
                <MenuItem key={pageSize} value={pageSize}>
                  Show: {pageSize}
                </MenuItem>
              ))}
            </SelectComponent>
          </Box>

          <Button
            size="small"
            aria-label="Go to first page"
            variant="contained"
            onClick={() => gotoPage(0)}
            disabled={!canPreviousPage}
          >
            <Icons.KeyboardDoubleArrowLeftIcon />
          </Button>

          <Button
            size="small"
            aria-label="Go to preview page"
            variant="contained"
            onClick={() => previousPage()}
            disabled={!canPreviousPage}
          >
            <Icons.KeyboardArrowLeftIcon />
          </Button>
          <span>
            Page{' '}
            <strong>
              {pageIndex + 1} of {pageOptions.length}
            </strong>
          </span>
          <Button
            size="small"
            aria-label="Go to next page"
            variant="contained"
            onClick={() => nextPage()}
            disabled={!canNextPage}
          >
            <Icons.KeyboardArrowRightIcon />
          </Button>
          <Button
            size="small"
            aria-label="Go to Last page"
            variant="contained"
            onClick={() => gotoPage(pageCount - 1)}
            disabled={!canNextPage}
          >
            <Icons.KeyboardDoubleArrowRightIcon />
          </Button>
        </div>
      </PaginationTable>
    </>
  );
};
