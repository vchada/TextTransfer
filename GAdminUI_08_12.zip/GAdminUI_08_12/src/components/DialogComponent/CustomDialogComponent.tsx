import { Dialog } from '@mui/material';

interface DialogComponentProps {
  open: boolean;
  children: React.ReactNode;
  size: any;
  fullWidth: boolean;
}

export const CustomDialogComponent = ({ open, children, size, fullWidth }: DialogComponentProps) => {
  return (
    <Dialog
      className='z-60'
      fullWidth={fullWidth}
      maxWidth={size}
      disableEscapeKeyDown
      open={open}
      aria-labelledby="edit-dialog"
      sx={{
        zIndex: 3,

      }}
    >
      {children}
    </Dialog>
  );
};
