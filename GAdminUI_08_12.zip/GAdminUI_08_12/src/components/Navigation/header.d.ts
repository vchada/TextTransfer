export interface DataItemsProps {
  nameItem: string;
  icon: JSX.Element;
  value: number;
}

export interface NavigationDesktopProps {
  dataItems: DataItemsProps[];
}

export interface NavigationMobileProps {
  dataItems: DataItemsProps[];
}
