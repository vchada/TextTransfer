import { ContainerUserArea } from './styled';
import { Button, FormControl, Menu, MenuItem, Select } from '@mui/material';
import { type MouseEvent, useEffect, useState } from 'react';
import { HiUserCircle } from 'react-icons/hi';
import { useLocation, useNavigate } from 'react-router';
import { Link } from 'react-router-dom';
import { getUserInfo } from '../../../services/session.server';

export const UserArea = () => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const [selectedTable, setSelectedTable] = useState<any>('selectTable');
  const open = Boolean(anchorEl);
  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const userInfo = getUserInfo();

  const location = useLocation();

  useEffect(() => {
    const tableName = (location.pathname && !location.pathname.includes('feedback')) ? location.pathname.replace('/', '') : 'selectTable'
    setSelectedTable(tableName)
  }, [location]);

  const navigate = useNavigate();

  const handleChange = (event: any) => {
    if(event.target.value !== 'selectTable') {
      setSelectedTable(event.target.value)
      navigate("/" + event.target.value) 
    }
  }


  const handleLogout = () => {
    sessionStorage.clear();
    localStorage.clear();
    navigate('/')
  }

  return (
    <ContainerUserArea>
      <div>
        <div className='mx-4'>
            <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }} className='select-table-wrapper'>
            <Select
              labelId="demo-simple-select-standard-label"
              id="demo-simple-select-standard"
              value={selectedTable}
              onChange={handleChange}
              label="Table"
            >
              <MenuItem value={'selectTable'}>
                Select Table
              </MenuItem>
              {(userInfo.siteCode === 0) && (
              <MenuItem value={'gfrDetails'}>GEA Details</MenuItem>)}
              {(userInfo.siteCode === 0) && (<MenuItem value={'gfrAppTagRouting'}>GEA App Tag Routing</MenuItem>)}
              {(userInfo.siteCode === 0) && (<MenuItem value={'gfrPhoneMapping'}>GEA Phone Mapping</MenuItem>
)}
              <MenuItem value={'gfrOfficeHours'}>GEA Office Hours</MenuItem>
              <MenuItem value={'gfrOfficeHourScheduler'}>GEA Office Hour Scheduler</MenuItem>
              {(userInfo.siteCode === 0) && (
              <MenuItem value={'gfrUsers'}>GEA Users</MenuItem>
              )}
            </Select>
          </FormControl>
        </div>

        <div className='userInfo'>
          <Button
            id="basic-button"
            aria-controls={open ? 'basic-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
            onClick={handleClick}
          >
            <HiUserCircle />
            <span>{userInfo.userName}</span>
          </Button>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
          <MenuItem>
            {/* <Form action="/logout" method="post"> */}
              <button onClick={handleLogout} className="no-border rounded py-1">
                Logout
              </button>
            {/* </Form> */}
          </MenuItem>
            <MenuItem onClick={handleClose}><Link className="" to="/feedback">
            Feedback
          </Link></MenuItem>
          </Menu>
        </div>
      </div>
      
    </ContainerUserArea>
  );
};
