import { styled } from 'styled-components';

export const ContainerUserArea = styled.div`
  div {
    display: flex;

    div.userInfo {
      padding-right: 4px;
      button {
        gap: 0.4rem;
        align-items: center;
        span {
          color: #ffffff;
          text-transform: capitalize;
          line-height: 0;
          font-size: 0.8rem;
        }

        svg {
          font-size: 1.4rem;
          color: #ffffff;
        }
      }
    }

    div {
      .select-table-wrapper {
        div.MuiInputBase-colorPrimary.MuiInputBase-formControl::before {
          border-color: #fff !important;
        }

        div.MuiInputBase-colorPrimary.MuiInputBase-formControl {
          div.MuiSelect-select.MuiSelect-standard {
            color: #fff !important;
          }

          svg {
            color: #fff !important;
          }
        }
      }
    }

    div {
      .table-select {
        label {
          color: #fff
        }

        div {
          svg {
            color: #fff;
          }

          select {
            color: #fff;

            option {
              color: #000;
            }
          }

        }

        div::before {
          color: #fff;
          border-color: #fff;
        }
      }
    }
  }
`;
