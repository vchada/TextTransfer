import { createContext } from "react";

interface UserInfo {
    name: string;
    email: string;
}

export const UserInfoContext = createContext({} as UserInfo);