import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrOfficeHours
} from '../../assets/dummy-data/gfrOfficeHoursTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrOfficeHours, fetchGfrOfficeHours, updateGfrOfficeHours } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrOfficeHours>[]>(
    () => [
      {
        accessorKey: 'site_code',
        header: 'Site Code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_id,
          helperText: validationErrors?.gea_id,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_id: undefined,
            }),
        },
      },
      {
        accessorKey: 'open_time',
        header: 'Open Time',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          type: 'time',
          label: "Open Hour New",
          InputLabelProps: {
            shrink: true,
          },
          required: true,
          error: !!validationErrors?.open_time,
          helperText: validationErrors?.open_time,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              open_time: undefined,
            }),
        },
      },
      {
        accessorKey: 'close_time',
        header: 'Close Time',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          type: 'time',
          label: "Open Hour New",
          InputLabelProps: {
            shrink: true,
          },
          error: !!validationErrors?.close_time,
          helperText: validationErrors?.close_time,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              close_time: undefined,
            }),
        },
      },
      {
        accessorKey: 'comments',
        header: 'Comments',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
          error: !!validationErrors?.comments,
          helperText: validationErrors?.comments,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              comments: undefined,
            }),
        },
      },
      {
        accessorKey: 'phone_type',
        header: 'Phone Type',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Office", label: "Office" },
          { value: "Cell", label: "Cell"}
        ],
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.phone_type,
          helperText: validationErrors?.phone_type,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              phone_type: undefined,
            }),
        },
      },
      {
        accessorKey: 'day',
        header: 'Day',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Monday", label: "Monday" },
          { value: "Tuesday", label: "Tuesday" },
          { value: "Wednesday", label: "Wednesday" },
          { value: "Thursday", label: "Thursday" },
          { value: "Friday", label: "Friday" },
          { value: "Saturday", label: "Saturday" },
          { value: "Sunday", label: "Sunday" }
        ],
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.day,
          helperText: validationErrors?.day,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              day: undefined,
            }),
        },
      },
    ],
    [validationErrors],
  );

  //call CREATE hook
  const { mutateAsync: createUser, isPending: isCreatingUser } = useCreateUser();
  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  //call UPDATE hook
  const { mutateAsync: updateUser, isPending: isUpdatingUser } = useUpdateUser();

  //CREATE action
  const handleCreateUser: MRT_TableOptions<GfrOfficeHours>['onCreatingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await createUser(values);
    table.setCreatingRow(null); //exit creating mode
  };

  //UPDATE action
  const handleSaveUser: MRT_TableOptions<GfrOfficeHours>['onEditingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await updateUser(values);
    table.setEditingRow(null); //exit editing mode
  };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New Office Hour</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit Hours</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
        renderTopToolbar: ({ table }) => (
          <Box
              sx={() => ({
                display: 'flex',
                gap: '0.5rem',
                p: '8px',
                justifyContent: 'space-between',
              })}
            >
            <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
              <MRT_GlobalFilterTextField table={table} />
              <MRT_ToggleFiltersButton table={table} />
            </Box>
            {userInfo && userInfo.admin && <Box>
              <Button
                variant="contained"
                onClick={() => {
                  table.setCreatingRow(true); //simplest way to open the create row modal with no default values
                  //or you can pass in a row object to set default values with the `createRow` helper function
                  // table.setCreatingRow(
                  //   createRow(table, {
                  //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
                  //   }),
                  // );
                }}
              >
                Create New
              </Button>
            </Box>}
          </Box>
        ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string) => !!value.length;

function validateUser(user: GfrOfficeHours) {
  return {
    open_time: !validateRequired(user.open_time) ? 'Open time is Required' : '',
    close_time: !validateRequired(user.close_time) ? 'Close time is Required' : '',
    gea_id: !validateRequired(user.gea_id) ? 'ID is Required' : '',
    phone_type: !validateRequired(user.phone_type ? user.phone_type : '' ) ? 'Phone type is Required' : '',
    day: !validateRequired(user.day ? user.day : '') ? 'Day is Required' : '',
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrOfficeHours.get('/').then((res: any) => {
        response = res?.data || [];
      });
      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }
      const modifiedRes: any = []
      response.forEach((val: any) => {
        const splitVal = (val && val.phone_type_and_day && val.phone_type_and_day.split('#')?.length > 0) ? val.phone_type_and_day.split('#'): [];
        modifiedRes.push({...val, ...{phone_type: splitVal[0], day: splitVal[1]}})
      })

      return Promise.resolve(modifiedRes);
    },
    refetchOnWindowFocus: false,
  });
}




//CREATE hook (post new user to api)
function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHours) => {
      
      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      const reqBody: any = {
        gea_id: user.gea_id,
        phone_type_and_day: user.phone_type + '#' + user.day,
        close_time: user.close_time,
        open_time: convertTimeFormat(user.open_time),
        comment: user.comments,            
        site_code: user.site_code
      }
      let response: any;
      await addGfrOfficeHours.post('/', reqBody).then((res: any) => {
        response = res.data;
      });

      return Promise.resolve(response);
    },
    //client side optimistic update
    onMutate: (gfrOfficeHours: GfrOfficeHours) => {
      queryClient.setQueryData(
        ['users'],
        (prevUsers: any) =>
          [
            ...prevUsers,
            {
              ...gfrOfficeHours,
            },
          ] as GfrOfficeHours[],
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}

//UPDATE hook (put user in api)
function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrOfficeHours) => {

      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      const reqBody: any = {
        gea_id: user.gea_id,
        phone_type_and_day: user.phone_type + '#' + user.day,
        close_time: user.close_time,
        open_time: convertTimeFormat(user.open_time),
        comment: user.comments,        
        site_code: user.site_code

      }
      let response: any;
      await updateGfrOfficeHours.put('/', reqBody).then((res: any) => {
        response = res.data;
      });
      return Promise.resolve(response);
    },
    //client side optimistic update
    onMutate: (gfrOfficeHours: GfrOfficeHours) => {
      queryClient.setQueryData(['users'], (prevUsers: any) =>
        prevUsers?.map((prevUser: GfrOfficeHours) => (prevUser.gea_id === gfrOfficeHours.gea_id && prevUser.phone_type === gfrOfficeHours.phone_type && prevUser.day === gfrOfficeHours.day) ? gfrOfficeHours : prevUser   
        ),
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}

function convertTimeFormat(militaryTime: string): string {
  // Sanity check - should never happen
  if (!militaryTime) return '';

  const [hours, minutes] = militaryTime.split(':');
  const hour = parseInt(hours, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const normalHour = hour % 12 || 12;

  return `${normalHour}:${minutes} ${ampm}`;
}
