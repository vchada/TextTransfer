import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrAppTagRouting
} from '../../assets/dummy-data/gfrAppTagRoutingTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrAppTagRouting, fetchGfrAppTagRouting, updateGfrAppTagRouting } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrAppTagRouting>[]>(
    () => [
      {
        accessorKey: 'gea_id',
        header: 'gea_id',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_id,
          helperText: validationErrors?.gea_id,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_id: undefined,
            }),
        },
      },
      {
        accessorKey: 'disam_prompt',
        header: 'Disam Prompt',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.disam_prompt,
          helperText: validationErrors?.disam_prompt,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              disam_prompt: undefined,
            }),
        },
      },
      {
        accessorKey: 'app_tag',
        header: 'App tag',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.app_tag,
          helperText: validationErrors?.app_tag,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              app_tag: undefined,
            }),
        },
      },
      {
        accessorKey: 'gea_tag',
        header: 'GEA Tag',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_tag,
          helperText: validationErrors?.gea_tag,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_tag: undefined,
            }),
        },
      }
    ],
    [validationErrors],
  );

  //call CREATE hook
  const { mutateAsync: createUser, isPending: isCreatingUser } = useCreateUser();
  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  //call UPDATE hook
  const { mutateAsync: updateUser, isPending: isUpdatingUser } = useUpdateUser();

  //CREATE action
  const handleCreateUser: MRT_TableOptions<GfrAppTagRouting>['onCreatingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await createUser(values);
    table.setCreatingRow(null); //exit creating mode
  };

  //UPDATE action
  const handleSaveUser: MRT_TableOptions<GfrAppTagRouting>['onEditingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await updateUser(values);
    table.setEditingRow(null); //exit editing mode
  };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New TAG ROUTING</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit App Tag</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbar: ({ table }) => (
      <Box
          sx={() => ({
            display: 'flex',
            gap: '0.5rem',
            p: '8px',
            justifyContent: 'space-between',
          })}
        >
        <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <MRT_GlobalFilterTextField table={table} />
          <MRT_ToggleFiltersButton table={table} />
        </Box>
        {userInfo && userInfo.admin && <Box>
          <Button
            variant="contained"
            onClick={() => {
              table.setCreatingRow(true); //simplest way to open the create row modal with no default values
              //or you can pass in a row object to set default values with the `createRow` helper function
              // table.setCreatingRow(
              //   createRow(table, {
              //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
              //   }),
              // );
            }}
          >
            Create New
          </Button>
        </Box>}
      </Box>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string) => !!value.length;

function validateUser(user: GfrAppTagRouting) {
  return {
    disam_prompt: !validateRequired(user.disam_prompt) ? 'Disam prompt is Required' : '',
    app_tag: !validateRequired(user.app_tag) ? 'App tag is Required' : '',
    gea_id: !validateRequired(user.gea_id) ? 'ID is Required' : '',
    gea_tag: !validateRequired(user.gea_tag) ? 'GEA tag is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrAppTagRouting.get('/').then((res: any) => {
        response = res?.data?.Items;
      });

      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}




//CREATE hook (post new user to api)
function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrAppTagRouting) => {
      
      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      const reqBody: any = {
        "disam_prompt": user.disam_prompt,
        "app_tag": user.app_tag,
        "gea_tag": user.gea_tag
      }

      let response: any;
      await addGfrAppTagRouting.post('/', reqBody).then((res: any) => {
        response = res.data;
      });

      return Promise.resolve(response);
    },
    //client side optimistic update
    onMutate: (gfrAppTagRouting: GfrAppTagRouting) => {
      queryClient.setQueryData(
        ['users'],
        (prevUsers: any) =>
          [
            ...prevUsers,
            {
              ...gfrAppTagRouting,
            },
          ] as GfrAppTagRouting[],
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}

//UPDATE hook (put user in api)
function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (user: GfrAppTagRouting) => {

      // await new Promise((resolve) => setTimeout(resolve, 1000)); //fake api call
      const reqBody: any = {
        "disam_prompt": user.disam_prompt,
        "app_tag": user.app_tag,
        "gea_tag": user.gea_tag
      }
      let response: any;
      await updateGfrAppTagRouting.put('/', reqBody).then((res: any) => {
        response = res.data;
      });
      return Promise.resolve(response);
    },
    //client side optimistic update
    onMutate: (gfrAppTagRouting: GfrAppTagRouting) => {
      queryClient.setQueryData(['users'], (prevUsers: any) =>
        prevUsers?.map((prevUser: GfrAppTagRouting) =>
          prevUser.gea_id === gfrAppTagRouting.gea_id ? gfrAppTagRouting : prevUser,
        ),
      );
    },
    // onSettled: () => queryClient.invalidateQueries({ queryKey: ['users'] }), //refetch users after mutation, disabled for demo
  });
}
