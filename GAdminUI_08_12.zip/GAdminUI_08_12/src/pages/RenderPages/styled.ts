import {styled} from 'styled-components';

export const ContainerRenderPages = styled.main`
  width: 100%;
  height: 100%;
`;
