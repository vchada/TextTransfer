import { getUserInfo } from "../services/session.server";
import { redirect, useNavigate } from "react-router";
import { RenderPages } from "../pages/RenderPages/RenderPages"
import { useEffect } from "react";

export async function loader() {
  // Check if the user is already logged in
  const userId = await getUserInfo();
  if (!userId) {
    throw redirect("/login");
  } else {
    return { userId };
  }
}

export default function Index() {

  const navigate = useNavigate();
    useEffect(() => {
      const userId = getUserInfo();
      if (!userId) {
        navigate("/login")
      }
    });

  return (
    <div>
      <RenderPages tablename='gfrPhoneMapping'/>
    </div>
  );
}
