window.VITE_BASE_URL='https://o5sg2sozq2.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_BASE_URL_STATE_PRIORITY = 'https://b3rrj59gi7.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_BASE_URL_HOURS_OF_OPERATION = 'https://1ke97zdw5b.execute-api.us-east-1.amazonaws.com/sbx';
window.VITE_ENV='IN1';
window.VITE_CCP_REGION='us-east-1';
window.VITE_CCP_URL= 'https://gwe1-telecom-dv1-conn-001.my.connect.aws/ccp-v2';
window.VITE_CCP_LOGIN_URL= 'https://launcher.myapps.microsoft.com/api/signin/7071b979-492a-4b9b-ad79-858d91c41084?tenantId=7389d8c0-3607-465c-a69f-7d4426502912';
window.VITE_CCP_LOGOUT_URL= 'https://login.microsoftonline.com/7389d8c0-3607-465c-a69f-7d4426502912/oauth2/v2.0/logout?post_logout_redirect_uri=https://gwe1-telecom-dv1-conn-001.my.connect.aws/ccp-v2';
window.VITE_CCP_CLIENT_ID= '03ec2238-c3d3-4a36-8a6b-d4a1468f89b3';

window.VITE_BASE_URL='https://o5sg2sozq2.execute-api.us-east-1.amazonaws.com'
window.VITE_BASE_URL_FEEDBACK = 'https://ahdmgjd9b2.execute-api.us-east-1.amazonaws.com/'
window.VITE_BASE_URL_LOGIN='https://eccdv1app11.geico.net:5656/aspect/authenticateUser'


window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOURS = 'https://cnde2st4of-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllOfficeHourDetails'
window.VITE_BASE_URL_ADD_GFR_OFFICE_HOURS = 'https://cnde2st4of-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaOfficeHours'
window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOURS = 'https://cnde2st4of-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaOfficeHours'



window.VITE_BASE_URL_FETCH_GFR_DETAIL = 'https://klz5e721de-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllDetails'
window.VITE_BASE_URL_ADD_GFR_DETAIL = 'https://klz5e721de-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaDetail'
window.VITE_BASE_URL_UPDATE_GFR_DETAIL = 'https://klz5e721de-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaDetail'


window.VITE_BASE_URL_FETCH_GFR_PHONE_MAPPING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllPhoneMappings'
window.VITE_BASE_URL_ADD_GFR_PHONE_MAPPING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaPhoneMapping'
window.VITE_BASE_URL_UPDATE_GFR_PHONE_MAPPING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaPhoneMapping'


window.VITE_BASE_URL_FETCH_GFR_APP_TAG_ROUTING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllAppTagRoutings'
window.VITE_BASE_URL_ADD_GFR_APP_TAG_ROUTING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaAppTagRouting'
window.VITE_BASE_URL_UPDATE_GFR_APP_TAG_ROUTING = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaAppTagRouting'


window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOUR_SCHEDULER = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllOfficeHourSchedules'
window.VITE_BASE_URL_ADD_GFR_OFFICE_HOUR_SCHEDULER = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaOfficeHoursSchedule'
window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOUR_SCHEDULER = 'https://r5zgpyyhb3-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaOfficeHoursSchedules'




window.VITE_BASE_URL_FETCH_GFR_USERS = 'https://9omjnc8k4a-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/GetAllUsers'
window.VITE_BASE_URL_ADD_GFR_USERS = 'https://9omjnc8k4a-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/createGeaUsers'
window.VITE_BASE_URL_UPDATE_GFR_USERS = 'https://9omjnc8k4a-vpce-0241bb4956bf07b7a.execute-api.us-east-1.amazonaws.com/dv1/GEA/updateGeaUsers'

