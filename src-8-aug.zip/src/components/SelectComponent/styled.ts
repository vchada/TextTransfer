import { FormControl } from '@mui/material';
import {styled} from 'styled-components';

export const StyledFormControl = styled(FormControl)`
    width: 100%;

    label {
        color: #1f1f1f;
    }

    .Mui-focused {
        color: #1a1a1a !important;
    }

    &:hover .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline {
        border-color: gray;
    }
    .MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline {
        border-color: gray;
    }

    .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline {
        border-color: gray;
    }
`;
