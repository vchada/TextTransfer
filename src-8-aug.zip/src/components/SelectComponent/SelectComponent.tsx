import { useId } from 'react';
import { InputLabel, Select } from '@mui/material';
import { StyledFormControl } from './styled';

export const SelectComponent = ({ children, labelSelect = '', ...rest }: any) => {
  const generateIdSelect = useId();

  return (
    <StyledFormControl size="small" aria-label={`filter.${generateIdSelect}`}>
      <InputLabel htmlFor={`select_field.${generateIdSelect}`} aria-label={generateIdSelect} >
        {labelSelect}
      </InputLabel>
      <Select
        label={labelSelect}
        aria-label={generateIdSelect}
        inputProps={{
          id: `select_field.${generateIdSelect}`,
        }}
        {...rest}
      >
        {children}
      </Select>
    </StyledFormControl>
  );
};


