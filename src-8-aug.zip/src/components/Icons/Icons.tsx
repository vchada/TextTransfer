import {
  MdEdit as EditIcon,
  MdKeyboardDoubleArrowLeft as KeyboardDoubleArrowLeftIcon,
  MdKeyboardDoubleArrowRight as KeyboardDoubleArrowRightIcon,
  MdSettingsBackupRestore as SettingsBackupRestoreIcon,
  MdOutlineKeyboardArrowLeft as KeyboardArrowLeftIcon,
  MdOutlineKeyboardArrowRight as KeyboardArrowRightIcon,
} from 'react-icons/md';
import {
  IoMdArrowDropup as ArrowDropUpIcon,
  IoMdArrowDropdown as ArrowDropDownIcon,
} from 'react-icons/io';

export {
  EditIcon,
  ArrowDropUpIcon,
  ArrowDropDownIcon,
  KeyboardDoubleArrowLeftIcon,
  KeyboardDoubleArrowRightIcon,
  KeyboardArrowRightIcon,
  KeyboardArrowLeftIcon,
  SettingsBackupRestoreIcon,
};
