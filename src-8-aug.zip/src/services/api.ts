import axios from 'axios';

export const api = axios.create({
  baseURL: window.VITE_BASE_URL
});

export const feedbackAPI = axios.create({
  baseURL: window.VITE_BASE_URL_FEEDBACK
});

export const loginAPI = axios.create({
  baseURL: 'https://jsonplaceholder.typicode.com/posts'
});

// GFR OFFICE HOURS API - START
export const fetchGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOURS
});
export const addGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_OFFICE_HOURS
});
export const updateGfrOfficeHours = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOURS
});
// GFR OFFICE HOURS API - END

// GFR Details API - START
export const fetchGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_DETAIL
});
export const addGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_DETAIL
});
export const updateGfrDetail = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_DETAIL
});
// GFR Details API - END

// GFR Phone Mapping API - START
export const fetchGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_PHONE_MAPPING
});
export const addGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_PHONE_MAPPING
});
export const updateGfrPhoneMapping = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_PHONE_MAPPING
});
// GFR Phone Mapping API - END

// GFR APP TAG ROUTING API - START
export const fetchGfrAppTagRouting = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_APP_TAG_ROUTING
});
export const addGfrAppTagRouting = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_APP_TAG_ROUTING
});
export const updateGfrAppTagRouting = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_APP_TAG_ROUTING
});
// GFR APP TAG ROUTING API - END

// GFR OFFICE HOUR SCHEDULER API - START
export const fetchGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_OFFICE_HOUR_SCHEDULER
});
export const addGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_OFFICE_HOUR_SCHEDULER
});
export const updateGfrOfficeHourScheduler = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_OFFICE_HOUR_SCHEDULER
});
// GFR OFFICE HOUR SCHEDULER API - END

// GFR USER API - START
export const fetchGfrUser = axios.create({
  baseURL: window.VITE_BASE_URL_FETCH_GFR_USERS
});
export const addGfrUser = axios.create({
  baseURL: window.VITE_BASE_URL_ADD_GFR_USERS
});
export const updateGfrUser = axios.create({
  baseURL: window.VITE_BASE_URL_UPDATE_GFR_USERS
});
// GFR USER API - END

fetchGfrDetail.interceptors.request.use(async (request: any) => {
    // add auth header with jwt if token is set
    const token = sessionStorage.getItem("token");
    // except for /login endpoint
    if (!request.url.includes('/login') && token !== null && token !== undefined) {
        request.headers.common.Authorization = `Bearer ${token}`;
    }
    return request;
});

fetchGfrDetail.interceptors.response.use(async (res: any) => { 
    console.log(res)
    return res
});
