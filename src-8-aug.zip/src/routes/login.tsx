import { createUserSession, getUserInfo } from '../services/session.server';
import geico_img from '../../public/geico.png';
import { useEffect, useState } from 'react';
import { fetchGfrUser, loginAPI } from '../services/api';
import { redirect, useNavigate } from 'react-router';
import { LoadingComponent } from '../components/LoadingComponent/LoadingComponent';
import { Button, TextField } from '@mui/material';
import { gfrUsersDummydata } from '../assets/dummy-data/gfrUsersDummyData';

export const meta: any = () => {
  return [
    { title: 'New React Router App' },
    { name: 'description', content: 'Welcome to React Router!' },
  ];
};

export default function Login({ actionData }: any) {
  const style = {
    color: '#00a6ff',
  };

  const navigate = useNavigate();

  useEffect(() => {
    const userId = getUserInfo();
    if (userId) {
      navigate('/');
    }
  });

  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const closeBanner = () => {
    setSuccessMsg('');
    setErrorMsg('');
  };

  const handleChange = (e: any) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({ ...prevState, [name]: value }));
  };

  const [formData, setFormData] = useState({
    userId: '',
    password: '',
  });

  const onSubmit = async () => {
    const userId = formData.userId;
    const password = formData.password;

    

    const payload = { userName: userId, password: password };
    setIsLoading(true);
    //TODO - Uncomment for API Call from 59 - 71
    loginAPI
      .post('/', payload).then((res) => {
      if (res) {
        fetchUserDetails(res.data, userId);
      }

    setIsLoading(false)
    })
    .catch(() => {
      setErrorMsg('There is some issue. Please try again.');
    setIsLoading(false)
    });

    //TODO - Comment below till 87
    // if (userId !== 'test@mail.com' || password !== 'password') {
    //   return setErrorMsg('Invalid userId or password');
    // }

    // const userInfo: any = {
    //   userName: 'A266952',
    //   mail: null,
    //   name: 'Venkat Chada',
    //   cn: 'Venkat Chada',
    //   gfrID: '0',
    //   isvalid: true,
    //   admin: true,
    // };
    // fetchUserDetails(userInfo, userId);
  };

  const fetchUserDetails = (userInfo: any, userId: string) => {
    
    let response: any;
      fetchGfrUser.get('/').then((res: any) => {
        response = res.data;
      });

      // ToDO - Need to comment below one line
      response = gfrUsersDummydata;
      if (userInfo && userInfo.gfrID && response.length > 0) {
        const actualUserDetails = response.find((item: any) => item.gea_id === userInfo.gfrID);
        const newUserInfo: any = {
          userName: actualUserDetails.user_name ,
          mail: actualUserDetails.email,
          name: actualUserDetails.gea_name,
          cn: userInfo.cn,
          gfrID: actualUserDetails.gea_id,
          isvalid: userInfo.isvalid,
          admin: actualUserDetails.is_admin,
        };

        // Create a session
        createUserSession({
          userId: userId,
          userInfo: newUserInfo,
        });
        setIsLoading(false);
        redirect('/');
      } else {
        console.log('No response from All user details API')
      }
    
  };

  return (
    <div>
      {isLoading && <LoadingComponent />}
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-md">
          <h2 className="text-2xl font-bold mb-6 text-center" style={style}>
            GFR Admin Console
          </h2>
          <div className="w-full inline-flex">
            <div className="w-1/4">
              <img
                src={geico_img}
                alt="React Router"
                className="block w-full h-full"
                style={{display: 'block'}}
              />
            </div>
            <form onSubmit={onSubmit} className="w-3/4 px-4">
            <div >
              <div className="mb-6">
                
                <TextField label="User ID" variant="standard"
                  type="userId"
                  id="userId"
                  value={formData.userId}
                  onChange={handleChange}
                  name="userId"
                  className="w-full"
                  required
                  placeholder="Enter user Id"
                />
              </div>
              <div className="mb-6">
                
                <TextField label="Password" variant="standard"
                  type="password"
                  id="password"
                  value={formData.password}
                  name="password"
                  className="w-full"
                  placeholder="Enter your password"
                  required
                  onChange={handleChange}
                />
              </div>

              {successMsg && (
                <div className="success-banner">
                  {successMsg}{' '}
                  <a onClick={closeBanner} className="close">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-x-lg"
                      viewBox="0 0 16 16"
                    >
                      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
                    </svg>
                  </a>
                </div>
              )}

              {errorMsg && (
                <div className="error-banner">
                  {errorMsg}{' '}
                  <a onClick={closeBanner} className="close">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      fill="currentColor"
                      className="bi bi-x-lg"
                      viewBox="0 0 16 16"
                    >
                      <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z" />
                    </svg>
                  </a>
                </div>
              )}

              <div className="flex">
                <Button variant="contained"
                  disabled={!formData.userId || !formData.password}
                  type="submit"
                  style={{marginLeft: 'auto'}}
                >
                  Sign In
                </Button>
              </div>
              {actionData?.error ? (
                <div className="flex flex-row">
                  <p className="text-red-600 mt-4 ">{actionData?.error}</p>
                </div>
              ) : null}
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
