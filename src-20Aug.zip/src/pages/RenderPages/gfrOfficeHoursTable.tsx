import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrOfficeHours
} from '../../assets/dummy-data/gfrOfficeHoursTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrOfficeHours, fetchGfrOfficeHours, updateGfrOfficeHours } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrOfficeHours>[]>(
    () => [
      {
        accessorKey: 'site_code',
        header: 'Site Code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.site_code,
          helperText: validationErrors?.site_code,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              site_code: undefined,
            }),
        },
      },
      {
        accessorKey: 'open_time',
        header: 'Open Time',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          type: 'time',
          label: "Open Hour New",
          value: convertTimeTo24HourFormat(row.original.open_time),
          InputLabelProps: {
            shrink: true,
          },
          required: true,
          error: !!validationErrors?.open_time,
          helperText: validationErrors?.open_time,
          onChange: (e: any) => {
            row._valuesCache.open_time = convertTimeTo12HourFormat(e.target.value);
            row.original.open_time = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              open_time: undefined,
            }),
        }),
      },
      {
        accessorKey: 'close_time',
        header: 'Close Time',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          required: true,
          type: 'time',
          label: "Close Hour New",
          value: convertTimeTo24HourFormat(row.original.close_time),
          InputLabelProps: {
            shrink: true,
          },
          error: !!validationErrors?.close_time,
          helperText: validationErrors?.close_time,
          onChange: (e: any) => {
            row._valuesCache.close_time = convertTimeTo12HourFormat(e.target.value);
            row.original.close_time = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              close_time: undefined,
            }),
        }),
      },
      {
        accessorKey: 'comments',
        header: 'Comments',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
          error: !!validationErrors?.comments,
          helperText: validationErrors?.comments,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              comments: undefined,
            }),
        },
      },
      {
        accessorKey: 'phone_type',
        header: 'Phone Type',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Office", label: "Office" },
          { value: "Cell", label: "Cell"}
        ],
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.phone_type,
          helperText: validationErrors?.phone_type,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              phone_type: undefined,
            }),
        },
      },
      {
        accessorKey: 'day',
        header: 'Day',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Monday", label: "Monday" },
          { value: "Tuesday", label: "Tuesday" },
          { value: "Wednesday", label: "Wednesday" },
          { value: "Thursday", label: "Thursday" },
          { value: "Friday", label: "Friday" },
          { value: "Saturday", label: "Saturday" },
          { value: "Sunday", label: "Sunday" }
        ],
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.day,
          helperText: validationErrors?.day,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              day: undefined,
            }),
        },
      },
    ],
    [validationErrors],
  );


  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();

  
  //UPDATE hook (put user in api)
  const queryClientInstance = useQueryClient();

    //call CREATE hook
  const { mutateAsync: createUser, isPending: isCreatingUser } = useMutation({
    mutationFn: async (user: GfrOfficeHours) => {
      const reqBody: any = {
        gea_id: user.gea_id,
        phone_type_and_day: user.phone_type + '#' + user.day,
        close_time: !(user.close_time.includes('AM') || user.close_time.includes('PM')) ? convertTimeTo12HourFormat(user.close_time): user.close_time,
        open_time: !(user.open_time.includes('AM') || user.open_time.includes('PM')) ? convertTimeTo12HourFormat(user.open_time): user.open_time,
        comment: user.comments,
        site_code: user.site_code
      };
      let response: any;
      await addGfrOfficeHours.post('/', reqBody).then((res: any) => {
        response = res.data;
      });
      return Promise.resolve(response);
    },
    // Refetch users only if update API call is successful
    onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
  });


  //CREATE action
  const handleCreateUser: MRT_TableOptions<GfrOfficeHours>['onCreatingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await createUser(values); // Call API to create data
    table.setCreatingRow(null); // Exit creating mode
    // Data will be refreshed automatically due to query invalidation
  };

  const { mutateAsync: updateUser, isPending: isUpdatingUser } = useMutation({
    mutationFn: async (user: GfrOfficeHours) => {
      const reqBody: any = {
        gea_id: user.gea_id,
        phone_type_and_day: user.phone_type + '#' + user.day,
        close_time: !(user.close_time.includes('AM') || user.close_time.includes('PM')) ? convertTimeTo12HourFormat(user.close_time): user.close_time,
        open_time: !(user.open_time.includes('AM') || user.open_time.includes('PM')) ? convertTimeTo12HourFormat(user.open_time): user.open_time,
        comment: user.comments,
        site_code: user.site_code
      };
      let response: any;
      await updateGfrOfficeHours.put('/', reqBody).then((res: any) => {
        response = res.data;
      });
      return Promise.resolve(response);
    },
    // Refetch users only if update API call is successful
    onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
  });

  //UPDATE action
  const handleSaveUser: MRT_TableOptions<GfrOfficeHours>['onEditingRowSave'] = async ({
    values,
    table,
  }) => {
    const newValidationErrors = validateUser(values);
    if (Object.values(newValidationErrors).some((error) => error)) {
      setValidationErrors(newValidationErrors);
      return;
    }
    setValidationErrors({});
    await updateUser(values); // Call API to update data
    table.setEditingRow(null); // Exit editing mode
    // Data will be refreshed automatically due to query invalidation
  };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New Office Hour</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit Hours</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
        renderTopToolbar: ({ table }) => (
          <Box
              sx={() => ({
                display: 'flex',
                gap: '0.5rem',
                p: '8px',
                justifyContent: 'space-between',
              })}
            >
            <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
              <MRT_GlobalFilterTextField table={table} />
              <MRT_ToggleFiltersButton table={table} />
            </Box>
            {userInfo && userInfo.admin && <Box>
              <Button
                variant="contained"
                onClick={() => {
                  table.setCreatingRow(true);
                }}
              >
                Create New
              </Button>
            </Box>}
          </Box>
        ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string | null | undefined) => !!value && value.length > 0;

function validateUser(user: GfrOfficeHours) {
  return {
    open_time: !validateRequired(user.open_time) ? 'Open time is Required' : '',
    close_time: !validateRequired(user.close_time) ? 'Close time is Required' : '',
    site_code: !validateRequired(user.site_code) ? 'Site code is Required' : '',
    phone_type: !validateRequired(user.phone_type ? user.phone_type : '' ) ? 'Phone type is Required' : '',
    day: !validateRequired(user.day ? user.day : '') ? 'Day is Required' : '',
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrOfficeHours.get('/').then((res: any) => {
        response = res?.data || [];
      });
      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }
      const modifiedRes: any = []
      response.forEach((val: any) => {
        const splitVal = (val && val.phone_type_and_day && val.phone_type_and_day.split('#')?.length > 0) ? val.phone_type_and_day.split('#'): [];
        modifiedRes.push({...val, ...{phone_type: splitVal[0], day: splitVal[1]}})
      })

      return Promise.resolve(modifiedRes);
    },
    refetchOnWindowFocus: false,
  });
}

function convertTimeTo12HourFormat(time: string): string {
  // Expects format "hh:mm
  if (!time) return '';

  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const normalHour = hour % 12 || 12;

  return `${normalHour}:${minutes} ${ampm}`;
}


function convertTimeTo24HourFormat(normalTime: string): string {
  // Expects format "hh:mm AM/PM"
  if (!normalTime) return '';

  const [time, period] = normalTime.trim().split(' ');
  if (!time || !period) return '';

  const [hours, minutes] = time.split(':');
  let hour = parseInt(hours, 10);

  if (period.toUpperCase() === 'PM' && hour !== 12) {
    hour += 12;
  } else if (period.toUpperCase() === 'AM' && hour === 12) {
    hour = 0;
  }

  const hourStr = hour.toString().padStart(2, '0');
  return `${hourStr}:${minutes}`;
}
  