import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,  
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { type GfrDetails } from '../../assets/dummy-data/gfrDetailsDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrDetail, fetchGfrDetail, updateGfrDetail } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrDetails>[]>(
    () => [
      {
        accessorKey: 'gea_id',
        header: 'ID',
        enableEditing: false,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
          error: !!validationErrors?.gea_id,
          helperText: validationErrors?.gea_id,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_id: undefined,
            }),
        },
        position: 'test'
      },
      {
        accessorKey: 'gea_name',
        header: 'Name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },

      {
        accessorKey: 'gea_location',
        header: 'Location',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },
      
      {
        accessorKey: 'site_code',
        header: 'Site code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },

      // {
      //   accessorKey: 'gea_hunt_spanish',
      //   header: 'Hunt Spanish',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_hunt_spanish_service',
      //   header: 'Hunt Spanish Service',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      //   minSize: 250
      // },

      // {
      //   accessorKey: 'gea_hunt_sales',
      //   header: 'Hunt Sales',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_hunt_service',
      //   header: 'Hunt Service',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_hunt_dealership',
      //   header: 'Hunt Dealership',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      {
        accessorKey: 'gea_welcome_prompt',
        header: 'Welcome Prompt',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },

      {
        accessorKey: 'gea_commercial_flag',
        header: 'Commercial Flag',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Yes", label: "Yes" },
          { value: "No", label: "No"}
        ],
        muiEditTextFieldProps: {
          required: false,
        },
      },

      {
        accessorKey: 'gea_autosvc_flag',
        header: 'Auto Svc Flag',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Yes", label: "Yes" },
          { value: "No", label: "No"}
        ],
        muiEditTextFieldProps: {
          required: false,
        },
      },

      // {
      //   accessorKey: 'no_match_ani_xfer_to_sales',
      //   header: 'No match',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_address_prompt',
      //   header: 'Address Prompt',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      {
        accessorKey: 'gea_state',
        header: 'State',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },

      {
        accessorKey: 'timezone',
        header: 'Timezone',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "America/New_York", label: "America/New_York" },
          { value: "America/Chicago", label: "America/Chicago"},
          { value: "America/Denver", label: "America/Denver"},
          { value: "America/Phoenix", label: "America/Phoenix"},
          { value: "America/Los_Angeles", label: "America/Los_Angeles"},
          { value: "Pacific/Honolulu", label: "Pacific/Honolulu"}
        ],
        muiEditTextFieldProps: {
          required: false,
        },
      },

      // {
      //   accessorKey: 'gea_office_hours_prompt',
      //   header: 'Office Hours prompt',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_office_hours_flag',
      //   header: 'Office Hours Flag',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      {
        accessorKey: 'gea_office_close_flag',
        header: 'Office Close Flag',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Yes", label: "Yes" },
          { value: "No", label: "No"}
        ],
        muiEditTextFieldProps: {
          required: false,
        },
      },

      {
        accessorKey: 'spanish_option',
        header: 'Spanish Option',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
        editSelectOptions: [
          { value: "Yes", label: "Yes" },
          { value: "No", label: "No"}
        ],
        muiEditTextFieldProps: {
          required: false,
        },
      },

      // {
      //   accessorKey: 'inq_vm_prompt',
      //   header: 'Inq vm prompt',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      {
        accessorKey: 'gea_cell_num',
        header: 'Cell Number',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false,
        },
      },

      // {
      //   accessorKey: 'dealership_available',
      //   header: 'Dealership Available',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      //   minSize: 250
      // },

      // {
      //   accessorKey: 'dst_exists',
      //   header: 'DST Exists',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },

      // {
      //   accessorKey: 'gea_holiday_list',
      //   header: 'Holiday List',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false,
      //   },
      // },
    ],
    [validationErrors],
  );

  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();

  //UPDATE hook (put user in api)
    const queryClientInstance = useQueryClient();
  
      //call CREATE hook
    const { mutateAsync: createUser, isPending: isCreatingUser } = useMutation({
      mutationFn: async (user: GfrDetails) => {
        const reqBody: any = {
        "gea_name": user.gea_name,
        "site_code": user.site_code,
        "gea_hunt_spanish": user.gea_hunt_spanish,
        "gea_hunt_spanish_service": user.gea_hunt_spanish_service,
        "gea_hunt_sales": user.gea_hunt_sales,
        "gea_hunt_service": user.gea_hunt_service,
        "gea_hunt_dealership": user.gea_hunt_dealership,
        "gea_welcome_prompt": user.gea_welcome_prompt,
        "gea_commercial_flag": user.gea_commercial_flag === "Yes" ? "Y" : "N",
        "gea_autosvc_flag": user.gea_autosvc_flag === "Yes" ? "Y" : "N",
        "no_match_ani_xfer_to_sales": user.no_match_ani_xfer_to_sales,
        "gea_address_prompt": user.gea_address_prompt,
        "gea_state": user.gea_state,
        "gea_location": user.gea_location,
        "timezone": user.timezone,
        "gea_office_hours_prompt": user.gea_office_hours_prompt,
        "gea_office_hours_flag": user.gea_office_hours_flag,
        "gea_office_close_flag": user.gea_office_close_flag === "Yes" ? "Y" : "N",
        "spanish_option": user.spanish_option === "Yes" ? "Y" : "N",
        "inq_vm_prompt": user.inq_vm_prompt,
        "gea_cell_num": user.gea_cell_num,
        "dealership_available": user.dealership_available,
        "dst_exists": user.dst_exists,
        "gea_holiday_list": user.gea_holiday_list,
      }
        let response: any;
        await addGfrDetail.post('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
  
    //CREATE action
    const handleCreateUser: MRT_TableOptions<GfrDetails>['onCreatingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await createUser(values); // Call API to create data
      table.setCreatingRow(null); // Exit creating mode
      // Data will be refreshed automatically due to query invalidation
    };
  
    const { mutateAsync: updateUser, isPending: isUpdatingUser } = useMutation({
      mutationFn: async (user: GfrDetails) => {
        const reqBody: any = {
        "gea_name": user.gea_name,
        "site_code": user.site_code,
        "gea_hunt_spanish": user.gea_hunt_spanish,
        "gea_hunt_spanish_service": user.gea_hunt_spanish_service,
        "gea_hunt_sales": user.gea_hunt_sales,
        "gea_hunt_service": user.gea_hunt_service,
        "gea_hunt_dealership": user.gea_hunt_dealership,
        "gea_welcome_prompt": user.gea_welcome_prompt,
        "gea_commercial_flag": user.gea_commercial_flag === "Yes" ? "Y" : "N",
        "gea_autosvc_flag": user.gea_autosvc_flag === "Yes" ? "Y" : "N",
        "no_match_ani_xfer_to_sales": user.no_match_ani_xfer_to_sales,
        "gea_address_prompt": user.gea_address_prompt,
        "gea_state": user.gea_state,
        "gea_location": user.gea_location,
        "timezone": user.timezone,
        "gea_office_hours_prompt": user.gea_office_hours_prompt,
        "gea_office_hours_flag": user.gea_office_hours_flag,
        "gea_office_close_flag": user.gea_office_close_flag === "Yes" ? "Y" : "N",
        "spanish_option": user.spanish_option === "Yes" ? "Y" : "N",
        "inq_vm_prompt": user.inq_vm_prompt,
        "gea_cell_num": user.gea_cell_num,
        "dealership_available": user.dealership_available,
        "dst_exists": user.dst_exists,
        "gea_holiday_list": user.gea_holiday_list,
      }
        let response: any;
        await updateGfrDetail.put('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
    //UPDATE action
    const handleSaveUser: MRT_TableOptions<GfrDetails>['onEditingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await updateUser(values); // Call API to update data
      table.setEditingRow(null); // Exit editing mode
      // Data will be refreshed automatically due to query invalidation
    };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true,
      columnPinning: { left: ['gea_id', 'gea_name', 'gea_location'] }
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit Location</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbar: ({ table }) => (
      <Box
          sx={() => ({
            display: 'flex',
            gap: '0.5rem',
            p: '8px',
            justifyContent: 'space-between',
          })}
        >
        <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <MRT_GlobalFilterTextField table={table} />
          <MRT_ToggleFiltersButton table={table} />
        </Box>
        {userInfo && userInfo.admin && <Box>
          <Button
            variant="contained"
            onClick={() => {
              table.setCreatingRow(true); //simplest way to open the create row modal with no default values
              //or you can pass in a row object to set default values with the `createRow` helper function
              // table.setCreatingRow(
              //   createRow(table, {
              //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
              //   }),
              // );
            }}
          >
            Create New
          </Button>
        </Box>}
      </Box>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last'
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string | null | undefined) => !!value && value.length > 0;

function validateUser(user: GfrDetails) {
  return {    
    gea_name: !validateRequired(user.gea_name) ? 'Name is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrDetail.get('/').then((res: any) => {
        response = res?.data?.Items;
      });
      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}
