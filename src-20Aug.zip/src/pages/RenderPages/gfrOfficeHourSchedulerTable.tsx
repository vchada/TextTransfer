import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrOfficeHourScheduler
} from '../../assets/dummy-data/gfrOfficeHourSchedulerTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrOfficeHourScheduler, fetchGfrOfficeHourScheduler, updateGfrOfficeHourScheduler } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrOfficeHourScheduler>[]>(
    () => [
      {
        accessorKey: 'site_code',
        header: 'site_code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.site_code,
          helperText: validationErrors?.site_code,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              site_code: undefined,
            }),
        },
      },
      {
        accessorKey: 'gea',
        header: 'GEA Name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea,
          helperText: validationErrors?.gea,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea: undefined,
            }),
        },
      },
      {
        accessorKey: 'open_hours_old',
        header: 'Open Hour Old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          type: 'time',
          label: "Open Hour New",
          value: convertTimeTo24HourFormat(row.original.open_hours_old),
          InputLabelProps: {
            shrink: true,
          },
          required: true,
          error: !!validationErrors?.open_hours_old,
          helperText: validationErrors?.open_hours_old,
          onChange: (e: any) => {
            row._valuesCache.open_hours_old = convertTimeTo12HourFormat(e.target.value);
            row.original.open_hours_old = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              open_hours_old: undefined,
            }),
        }),
      },
      {
        accessorKey: 'close_hours_old',
        header: 'Close Hour Old',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          required: true,
          type: 'time',
          label: "Close Hour New",
          value: convertTimeTo24HourFormat(row.original.close_hours_old),
          InputLabelProps: {
            shrink: true,
          },
          error: !!validationErrors?.close_hours_old,
          helperText: validationErrors?.close_hours_old,
          onChange: (e: any) => {
            row._valuesCache.close_hours_old = convertTimeTo12HourFormat(e.target.value);
            row.original.close_hours_old = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              close_hours_old: undefined,
            }),
        }),
      },
      {
        accessorKey: 'open_hours_new',
        header: 'Open Hour New',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          type: 'time',
          label: "Open Hour New",
          value: convertTimeTo24HourFormat(row.original.open_hours_new),
          InputLabelProps: {
            shrink: true,
          },
          required: true,
          error: !!validationErrors?.open_hours_new,
          helperText: validationErrors?.open_hours_new,
          onChange: (e: any) => {
            row._valuesCache.open_hours_new = convertTimeTo12HourFormat(e.target.value);
            row.original.open_hours_new = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              open_hours_new: undefined,
            }),
        }),
      },
      {
        accessorKey: 'close_hours_new',
        header: 'Close Hour New',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: ({ row }) => ({
          required: true,
          type: 'time',
          label: "Close Hour New",
          value: convertTimeTo24HourFormat(row.original.close_hours_new),
          InputLabelProps: {
            shrink: true,
          },
          error: !!validationErrors?.close_hours_new,
          helperText: validationErrors?.close_hours_new,
          onChange: (e: any) => {
            row._valuesCache.close_hours_new = convertTimeTo12HourFormat(e.target.value);
            row.original.close_hours_new = convertTimeTo12HourFormat(e.target.value);
          },
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              close_hours_new: undefined,
            }),
        }),
      },
      {
        accessorKey: 'gea_request_id',
        header: 'Request ID',
        enableEditing: false,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'table_name',
        header: 'Table Name',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'comments',
        header: 'Comments',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'full_day',
        header: 'Full Day',
        enableEditing: true,
        size: 80,
        editVariant: 'select',
      editSelectOptions: [
        { value: 'Yes', label: 'Yes' },
        { value: 'No', label: 'No' },
      ],
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'expiry_date',
        header: 'Expiry Date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          label: "Expiry Date",
          InputLabelProps: {
            shrink: true,
          },
          type: 'date',
          required: false
        },
      },
      {
        accessorKey: 'req_initiated_user',
        header: 'Request Initiated User',
        enableEditing: false,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
        minSize: 250
      },
      {
        accessorKey: 'request_status',
        header: 'Request Status',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: false
        },
      },
      {
        accessorKey: 'effective_date',
        header: 'Effective Date',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          label: "Effective Date",
          InputLabelProps: {
            shrink: true,
          },
          type: 'date',
          required: false,
        },
      },
    ],
    [validationErrors],
  );

  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  
  //UPDATE hook (put user in api)
    const queryClientInstance = useQueryClient();
  
      //call CREATE hook
    const { mutateAsync: createUser, isPending: isCreatingUser } = useMutation({
      mutationFn: async (user: GfrOfficeHourScheduler) => {
        const reqBody: any = {
          "gea_id": user.gea_id,
          "gea": user.gea,
          "close_hours_new": !(user.close_hours_new.includes('AM') || user.close_hours_new.includes('PM')) ? convertTimeTo12HourFormat(user.close_hours_new): user.close_hours_new,
          "open_hours_old": !(user.open_hours_old.includes('AM') || user.open_hours_old.includes('PM')) ? convertTimeTo12HourFormat(user.open_hours_old): user.open_hours_old,
          "gea_request_id": user.gea_request_id,
          "close_hours_old": !(user.close_hours_old.includes('AM') || user.close_hours_old.includes('PM')) ? convertTimeTo12HourFormat(user.close_hours_old): user.close_hours_old,
          "table_name": user.table_name,
          "comments": user.comments,
          "full_day": user.full_day === "Yes" ? "true" : "false",
          "req_created_dt_tm": user.req_created_dt_tm,
          "expiry_date": user.expiry_date,
          "req_initiated_user": user.req_initiated_user,
          "open_hours_new": !(user.open_hours_new.includes('AM') || user.open_hours_new.includes('PM')) ? convertTimeTo12HourFormat(user.open_hours_new): user.open_hours_new,
          "request_status": user.request_status,
          "effective_date": user.effective_date,
          "site_code": user.site_code,
        }
        let response: any;
        await addGfrOfficeHourScheduler.post('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
  
    //CREATE action
    const handleCreateUser: MRT_TableOptions<GfrOfficeHourScheduler>['onCreatingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await createUser(values); // Call API to create data
      table.setCreatingRow(null); // Exit creating mode
      // Data will be refreshed automatically due to query invalidation
    };
  
    const { mutateAsync: updateUser, isPending: isUpdatingUser } = useMutation({
      mutationFn: async (user: GfrOfficeHourScheduler) => {
        const reqBody: any = {
          "gea_id": user.gea_id,
          "gea": user.gea,
          "close_hours_new": !(user.close_hours_new.includes('AM') || user.close_hours_new.includes('PM')) ? convertTimeTo12HourFormat(user.close_hours_new): user.close_hours_new,
          "open_hours_old": !(user.open_hours_old.includes('AM') || user.open_hours_old.includes('PM')) ? convertTimeTo12HourFormat(user.open_hours_old): user.open_hours_old,
          "gea_request_id": user.gea_request_id,
          "close_hours_old": !(user.close_hours_old.includes('AM') || user.close_hours_old.includes('PM')) ? convertTimeTo12HourFormat(user.close_hours_old): user.close_hours_old,
          "table_name": user.table_name,
          "comments": user.comments,
          "full_day": user.full_day === "Yes" ? "true" : "false",
          "req_created_dt_tm": user.req_created_dt_tm,
          "expiry_date": user.expiry_date,
          "req_initiated_user": user.req_initiated_user,
          "open_hours_new": !(user.open_hours_new.includes('AM') || user.open_hours_new.includes('PM')) ? convertTimeTo12HourFormat(user.open_hours_new): user.open_hours_new,
          "request_status": user.request_status,
          "effective_date": user.effective_date,
          "site_code": user.site_code,
        }
        let response: any;
        await updateGfrOfficeHourScheduler.put('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
    //UPDATE action
    const handleSaveUser: MRT_TableOptions<GfrOfficeHourScheduler>['onEditingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await updateUser(values); // Call API to update data
      table.setEditingRow(null); // Exit editing mode
      // Data will be refreshed automatically due to query invalidation
    };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.site_code ?? '',
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New Office Hour Scheduler</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit Scheduled Hours</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbar: ({ table }) => (
      <Box
          sx={() => ({
            display: 'flex',
            gap: '0.5rem',
            p: '8px',
            justifyContent: 'space-between',
          })}
        >
        <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <MRT_GlobalFilterTextField table={table} />
          <MRT_ToggleFiltersButton table={table} />
        </Box>
        {userInfo && userInfo.admin && <Box>
          <Button
            variant="contained"
            onClick={() => {
              table.setCreatingRow(true); //simplest way to open the create row modal with no default values
              //or you can pass in a row object to set default values with the `createRow` helper function
              // table.setCreatingRow(
              //   createRow(table, {
              //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
              //   }),
              // );
            }}
          >
            Create New
          </Button>
        </Box>}
      </Box>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string | null | undefined) => !!value && value.length > 0;

function validateUser(user: GfrOfficeHourScheduler) {
  return {
    gea: !validateRequired(user.gea) ? 'GEA Name is Required' : '',
    site_code: !validateRequired(user.site_code) ? 'ID is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrOfficeHourScheduler.get('/').then((res: any) => {
        response = res?.data?.Items;
      });

      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}

function convertTimeTo12HourFormat(time: string): string {
  // Expects format "hh:mm
  if (!time) return '';

  const [hours, minutes] = time.split(':');
  const hour = parseInt(hours, 10);
  const ampm = hour >= 12 ? 'PM' : 'AM';
  const normalHour = hour % 12 || 12;

  return `${normalHour}:${minutes} ${ampm}`;
}


function convertTimeTo24HourFormat(normalTime: string): string {
  // Expects format "hh:mm AM/PM"
  if (!normalTime) return '';

  const [time, period] = normalTime.trim().split(' ');
  if (!time || !period) return '';

  const [hours, minutes] = time.split(':');
  let hour = parseInt(hours, 10);

  if (period.toUpperCase() === 'PM' && hour !== 12) {
    hour += 12;
  } else if (period.toUpperCase() === 'AM' && hour === 12) {
    hour = 0;
  }

  const hourStr = hour.toString().padStart(2, '0');
  return `${hourStr}:${minutes}`;
}
