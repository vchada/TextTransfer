import { Navigation } from '../../components/Navigation/Navigation';
import { ContainerRenderPages } from './styled';
import GfrDetailTable from './gfrDetailTable';
import GfrPhoneMappingTable from './gfrPhoneMappingTable';
import GfrOfficeHoursTable from './gfrOfficeHoursTable';
import GfrOfficeHourSchedulerTable from './gfrOfficeHourSchedulerTable';
import GfrAppTagRoutingTable from './gfrAppTagRoutingTable';
import GfrUsersTable from './gfrUsersTable';

export const RenderPages = ({tablename}: any) => {

  return (
    <ContainerRenderPages suppressHydrationWarning={true}>
      <Navigation/>
      {tablename == 'gfrDetails' && <GfrDetailTable/> }
      {tablename == 'gfrPhoneMapping' && <GfrPhoneMappingTable/> }
      {tablename == 'gfrOfficeHours' && <GfrOfficeHoursTable/> }
      {tablename == 'gfrOfficeHourScheduler' && <GfrOfficeHourSchedulerTable/> }
      {tablename == 'gfrAppTagRouting' && <GfrAppTagRoutingTable/> }    
      {tablename == 'gfrUsers' && <GfrUsersTable/> }      
    </ContainerRenderPages>
  );
};
