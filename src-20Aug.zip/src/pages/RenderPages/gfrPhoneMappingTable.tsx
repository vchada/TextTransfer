import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import { type GfrPhoneMapping } from '../../assets/dummy-data/gfrPhoneMappingTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrPhoneMapping, fetchGfrPhoneMapping, updateGfrPhoneMapping } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrPhoneMapping>[]>(
    () => [
      {
        accessorKey: 'phone_number',
        header: 'Phone Number',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.phone_number,
          helperText: validationErrors?.phone_number,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              open_time: undefined,
            }),
        },
      },
      {
        accessorKey: 'site_code',
        header: 'Site Code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_id,
          helperText: validationErrors?.gea_id,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_id: undefined,
            }),
        },
      },
      // {
      //   accessorKey: 'gea_dr_num',
      //   header: 'DR Number',
      //   enableEditing: true,
      //   size: 80,
      //   muiEditTextFieldProps: {
      //     required: false
      //   },
      // }
    ],
    [validationErrors],
  );

  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();

  //UPDATE hook (put user in api)
    const queryClientInstance = useQueryClient();
  
      //call CREATE hook
    const { mutateAsync: createUser, isPending: isCreatingUser } = useMutation({
      mutationFn: async (user: GfrPhoneMapping) => {
        const reqBody: any = { 
          "phone_number": user.phone_number,
          "gea_dr_num": user.gea_dr_num,
          "gea_id": user.gea_id
      }
        let response: any;
        await addGfrPhoneMapping.post('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
  
    //CREATE action
    const handleCreateUser: MRT_TableOptions<GfrPhoneMapping>['onCreatingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await createUser(values); // Call API to create data
      table.setCreatingRow(null); // Exit creating mode
      // Data will be refreshed automatically due to query invalidation
    };
  
    const { mutateAsync: updateUser, isPending: isUpdatingUser } = useMutation({
      mutationFn: async (user: GfrPhoneMapping) => {
        const reqBody: any = { 
          "phone_number": user.phone_number,
          "gea_dr_num": user.gea_dr_num,
          "gea_id": user.gea_id
      }
        let response: any;
        await updateGfrPhoneMapping.put('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
    //UPDATE action
    const handleSaveUser: MRT_TableOptions<GfrPhoneMapping>['onEditingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await updateUser(values); // Call API to update data
      table.setEditingRow(null); // Exit editing mode
      // Data will be refreshed automatically due to query invalidation
    };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.gea_id,
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New Phone Mapping</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit Phone Mapping</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
        renderTopToolbar: ({ table }) => (
          <Box
              sx={() => ({
                display: 'flex',
                gap: '0.5rem',
                p: '8px',
                justifyContent: 'space-between',
              })}
            >
            <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
              <MRT_GlobalFilterTextField table={table} />
              <MRT_ToggleFiltersButton table={table} />
            </Box>
            {userInfo && userInfo.admin && <Box>
              <Button
                variant="contained"
                onClick={() => {
                  table.setCreatingRow(true); //simplest way to open the create row modal with no default values
                  //or you can pass in a row object to set default values with the `createRow` helper function
                  // table.setCreatingRow(
                  //   createRow(table, {
                  //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
                  //   }),
                  // );
                }}
              >
                Create New
              </Button>
            </Box>}
          </Box>
        ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string | null | undefined) => !!value && value.length > 0;

function validateUser(user: GfrPhoneMapping) {
  return {
    phone_number: !validateRequired(user.phone_number) ? 'Phone number is Required' : '',
    site_code: !validateRequired(user.site_code) ? 'Site Code is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrPhoneMapping.get('/').then((res: any) => {
        response = res?.data?.Items;
      });

      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}

