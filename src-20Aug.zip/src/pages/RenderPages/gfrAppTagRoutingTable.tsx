import { useMemo, useState } from 'react';
import {
  MRT_EditActionButtons,
  MaterialReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  useMaterialReactTable,
  MRT_GlobalFilterTextField,
  MRT_ToggleFiltersButton,
} from 'material-react-table';
import {
  Box,
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Tooltip,
} from '@mui/material';
import {
  QueryClient,
  QueryClientProvider,
  useMutation,
  useQuery,
  useQueryClient,
} from '@tanstack/react-query';
import {
  type GfrAppTagRouting
} from '../../assets/dummy-data/gfrAppTagRoutingTableDummyData';
import EditIcon from '@mui/icons-material/Edit';
import { addGfrAppTagRouting, fetchGfrAppTagRouting, updateGfrAppTagRouting } from '../../services/api';
import { getUserInfo } from '../../services/session.server';

const Example = () => {
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string | undefined>
  >({});

  const columns = useMemo<MRT_ColumnDef<GfrAppTagRouting>[]>(
    () => [
      {
        accessorKey: 'site_code',
        header: 'site_code',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.site_code,
          helperText: validationErrors?.site_code,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              site_code: undefined,
            }),
        },
      },
      {
        accessorKey: 'disam_prompt',
        header: 'Disam Prompt',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.disam_prompt,
          helperText: validationErrors?.disam_prompt,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              disam_prompt: undefined,
            }),
        },
      },
      {
        accessorKey: 'app_tag',
        header: 'App tag',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.app_tag,
          helperText: validationErrors?.app_tag,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              app_tag: undefined,
            }),
        },
      },
      {
        accessorKey: 'gea_tag',
        header: 'GEA Tag',
        enableEditing: true,
        size: 80,
        muiEditTextFieldProps: {
          required: true,
          error: !!validationErrors?.gea_tag,
          helperText: validationErrors?.gea_tag,
          onFocus: () =>
            setValidationErrors({
              ...validationErrors,
              gea_tag: undefined,
            }),
        },
      }
    ],
    [validationErrors],
  );

  //call READ hook
  const {
    data: fetchedUsers = [],
    isError: isLoadingUsersError,
    isFetching: isFetchingUsers,
    isLoading: isLoadingUsers,
  } = useGetUsers();
  
  //UPDATE hook (put user in api)
    const queryClientInstance = useQueryClient();
  
      //call CREATE hook
    const { mutateAsync: createUser, isPending: isCreatingUser } = useMutation({
      mutationFn: async (user: GfrAppTagRouting) => {
        const reqBody: any = {
        "disam_prompt": user.disam_prompt,
        "app_tag": user.app_tag,
        "gea_tag": user.gea_tag,
        "site_code": user.site_code
      }
        let response: any;
        await addGfrAppTagRouting.post('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
  
    //CREATE action
    const handleCreateUser: MRT_TableOptions<GfrAppTagRouting>['onCreatingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await createUser(values); // Call API to create data
      table.setCreatingRow(null); // Exit creating mode
      // Data will be refreshed automatically due to query invalidation
    };
  
    const { mutateAsync: updateUser, isPending: isUpdatingUser } = useMutation({
      mutationFn: async (user: GfrAppTagRouting) => {
        const reqBody: any = {
        "disam_prompt": user.disam_prompt,
        "app_tag": user.app_tag,
        "gea_tag": user.gea_tag,
        "site_code": user.site_code
      }
        let response: any;
        await updateGfrAppTagRouting.put('/', reqBody).then((res: any) => {
          response = res.data;
        });
        return Promise.resolve(response);
      },
      // Refetch users only if update API call is successful
      onSuccess: () => queryClientInstance.invalidateQueries({ queryKey: ['users'] }),
    });
  
    //UPDATE action
    const handleSaveUser: MRT_TableOptions<GfrAppTagRouting>['onEditingRowSave'] = async ({
      values,
      table,
    }) => {
      const newValidationErrors = validateUser(values);
      if (Object.values(newValidationErrors).some((error) => error)) {
        setValidationErrors(newValidationErrors);
        return;
      }
      setValidationErrors({});
      await updateUser(values); // Call API to update data
      table.setEditingRow(null); // Exit editing mode
      // Data will be refreshed automatically due to query invalidation
    };

  const userInfo = getUserInfo();

  const table = useMaterialReactTable({
    columns,
    data: fetchedUsers,
    initialState: {
      showGlobalFilter: true
    },
    createDisplayMode: 'modal', //default ('row', and 'custom' are also available)
    editDisplayMode: 'modal', //default ('row', 'cell', 'table', and 'custom' are also available)
    enableEditing: userInfo && userInfo.admin ? true : false,
    enableTopToolbar: true,
    getRowId: (row) => row.site_code ?? '',
    muiToolbarAlertBannerProps: isLoadingUsersError
      ? {
          color: 'error',
          children: 'Error loading data',
        }
      : undefined,
    muiTableContainerProps: {
      sx: {
        minHeight: '500px',
      },
    },
    onCreatingRowCancel: () => setValidationErrors({}),
    onCreatingRowSave: handleCreateUser,
    onEditingRowCancel: () => setValidationErrors({}),
    onEditingRowSave: handleSaveUser,
    //optionally customize modal content
    renderCreateRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Create New TAG ROUTING</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    //optionally customize modal content
    renderEditRowDialogContent: ({ table, row, internalEditComponents }) => (
      <>
        <DialogTitle variant="h5">Edit App Tag</DialogTitle>
        <DialogContent sx={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {internalEditComponents} {/* or render custom edit components here */}
        </DialogContent>
        <DialogActions>
          <MRT_EditActionButtons variant="text" table={table} row={row} />
        </DialogActions>
      </>
    ),
    renderRowActions: ({ row, table }) => (
      <Box sx={{ display: 'flex', gap: '1rem' }}>
        <Tooltip title="Edit">
          <IconButton onClick={() => table.setEditingRow(row)}>
            <EditIcon />
          </IconButton>
        </Tooltip>
      </Box>
    ),
    renderTopToolbar: ({ table }) => (
      <Box
          sx={() => ({
            display: 'flex',
            gap: '0.5rem',
            p: '8px',
            justifyContent: 'space-between',
          })}
        >
        <Box sx={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <MRT_GlobalFilterTextField table={table} />
          <MRT_ToggleFiltersButton table={table} />
        </Box>
        {userInfo && userInfo.admin && <Box>
          <Button
            variant="contained"
            onClick={() => {
              table.setCreatingRow(true); //simplest way to open the create row modal with no default values
              //or you can pass in a row object to set default values with the `createRow` helper function
              // table.setCreatingRow(
              //   createRow(table, {
              //     //optionally pass in default values for the new row, useful for nested data or other complex scenarios
              //   }),
              // );
            }}
          >
            Create New
          </Button>
        </Box>}
      </Box>
    ),
    state: {
      isLoading: isLoadingUsers,
      isSaving: isCreatingUser || isUpdatingUser,
      showAlertBanner: isLoadingUsersError,
      showProgressBars: isFetchingUsers,
    },
    positionActionsColumn: 'last',
  });

  return <MaterialReactTable table={table} />;
};

const queryClient = new QueryClient();

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div style={{ margin: '0 100px' }}>
        <Example />
      </div>
    </QueryClientProvider>
  );
}

const validateRequired = (value: string | null | undefined) => !!value && value.length > 0;

function validateUser(user: GfrAppTagRouting) {
  return {
    disam_prompt: !validateRequired(user.disam_prompt) ? 'Disam prompt is Required' : '',
    app_tag: !validateRequired(user.app_tag) ? 'App tag is Required' : '',
    site_code: !validateRequired(user.site_code) ? 'ID is Required' : '',
    gea_tag: !validateRequired(user.gea_tag) ? 'GEA tag is Required' : ''
  };
}

//READ hook (get users from api)
function useGetUsers() {
  return useQuery<any[]>({
    queryKey: ['users'],
    queryFn: async () => {
      
      let response: any = [];
      await fetchGfrAppTagRouting.get('/').then((res: any) => {
        response = res?.data?.Items;
      });

      const userInfo = await getUserInfo();
      if (userInfo && userInfo.gfrID && userInfo.gfrID !== '0' && response.length > 0) {
        response = response.filter((item: any) => {
          return item.site_code === userInfo.siteCode;
        });
      }

      return Promise.resolve(response);
    },
    refetchOnWindowFocus: false,
  });
}
