export async function createUserSession({
  userId, userInfo
}: {
  userId: string;
  userInfo: any;
}) {
  sessionStorage.setItem(userId, JSON.stringify(userInfo))
  localStorage.setItem('userId', userId)

}


const getUserSession = (userId: string) => {
  return sessionStorage.getItem(userId);
};


export function getUserInfo() {
  const userIdAtt: string | null = localStorage.getItem('userId')
  if(userIdAtt) {
    const userInfoStr = getUserSession(userIdAtt) || ''
    return (userInfoStr && userInfoStr != '') ? JSON.parse(userInfoStr): null;
  } else {
    return undefined;
  }
}


