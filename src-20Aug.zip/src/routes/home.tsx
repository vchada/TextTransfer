import { getUserInfo } from "../services/session.server";
import { useNavigate } from "react-router";
import { useEffect } from "react";


export default function Index() {
  const navigate = useNavigate();
  useEffect(() => {
      const userInfo = getUserInfo();
      if (userInfo) {
        if(userInfo.siteCode === 0) {
          navigate("/gfrDetails")
        } else {
          navigate("/gfrOfficeHours")
        }
      } else {
        navigate("/login")
      }
    });

    return (
    <div></div>
    )
}
