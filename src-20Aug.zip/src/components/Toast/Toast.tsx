import { toast } from 'react-toastify';

export const errorToast = (messageError: string) =>
  toast.error(<span> {messageError}</span>, {
    pauseOnHover: false,
    closeOnClick: true,
    className: 'toast',
    position: 'top-right',
  });

export const warningToast = (messageWarning: string) =>
  toast.warning(
    <div className="toast_css">
      <span>{messageWarning}</span>
    </div>,
    { pauseOnHover: false, closeOnClick: true, position: 'top-right', },
  );

export const successToast = (messageSuccess: string) =>
  toast.success(
    <div className="toast_css">
      <span>{messageSuccess}</span>
    </div>,
    { pauseOnHover: false, closeOnClick: true, position: 'top-right', },
  );
