import { Dialog } from '@mui/material';

interface DialogComponentProps {
  open: boolean;
  // onClose: () => void;
  children: React.ReactNode;
}

export const QueueAddHOODialogComponent = ({ open, children }: DialogComponentProps) => {
  return (
    <Dialog
      fullWidth={false}
      maxWidth={'md'}
      open={open}
      disableEscapeKeyDown
      aria-labelledby="edit-dialog"
      sx={{
        zIndex: 3,

      }}
    >
      {children}
    </Dialog>
  );
};
