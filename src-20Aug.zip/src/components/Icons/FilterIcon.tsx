import React from 'react';

interface FilterIconProps {
	size?: number;
	color?: string;
}

const FilterIcon: React.FC<FilterIconProps> = ({ size = 24, color = 'black' }) => {
	return (
		<svg width={size} height={size} viewBox="0 0 25 24" fill={color} xmlns="http://www.w3.org/2000/svg">
			<path d="M4.98699 5.61C7.00699 8.2 10.737 13 10.737 13V19C10.737 19.55 11.187 20 11.737 20H13.737C14.287 20 14.737 19.55 14.737 19V13C14.737 13 18.457 8.2 20.477 5.61C20.987 4.95 20.517 4 19.687 4H5.77699C4.94699 4 4.47699 4.95 4.98699 5.61Z" fill={color} fillOpacity="0.56" />
		</svg>
	);
}

export default FilterIcon;
