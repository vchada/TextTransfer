import { TableRow } from '@mui/material';
import {styled} from 'styled-components';

export const NoDataTableRow = styled(TableRow)`
  width: 100%;
  height: 80px;
  position: relative;

  .contentNoData {
    top: 0;
    width: 100%;
    height: 100%;
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    background-color: var(--white);
    border-radius: 4px;
    border-bottom: 1px solid var(--gray-100);

    span {
      font-size: 1rem;
      font-weight: normal;
      word-wrap: normal;
      color: var(--gray-200);
    }

    svg {
      color: var(--red);
      font-size: 1.4rem;
    }
  }
`;
