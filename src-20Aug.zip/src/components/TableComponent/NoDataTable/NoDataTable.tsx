import { MdErrorOutline } from 'react-icons/md';
import { NoDataTableRow } from './styled';
import { memo } from 'react';

const NoDataTableComponent = () => {
  return (
    <NoDataTableRow>
      <td>
        <div className="contentNoData">
          <MdErrorOutline />
          <span>No Data</span>
        </div>
      </td>
    </NoDataTableRow>
  );
};

export const NoDataTable = memo(NoDataTableComponent);
