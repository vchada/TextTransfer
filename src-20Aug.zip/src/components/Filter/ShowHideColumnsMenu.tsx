import { Box, Button, Divider, Menu, type MenuProps } from '@mui/material';
import { useMemo, useState } from 'react';
import {
  type MRT_Column,
  MRT_ShowHideColumnsMenuItems,
  type MRT_TableInstance,
} from 'material-react-table';

interface ShowHideColumnsMenuProps extends Partial<MenuProps> {
  anchorEl: HTMLElement | null;
  onClose: () => void;
  table: MRT_TableInstance<any>;
}

const ShowHideColumnsMenu = ({
  anchorEl,
  onClose,
  table,
  ...rest
}: ShowHideColumnsMenuProps) => {
  const {
    getAllColumns,
    getAllLeafColumns,
    getCenterLeafColumns,
    getIsAllColumnsVisible,
    // getIsSomeColumnsPinned,
    getIsSomeColumnsVisible,
    getLeftLeafColumns,
    getRightLeafColumns,
    getState,
    options: {
      // enableColumnOrdering,
      // enableColumnPinning,
      enableHiding,
      localization,
      mrtTheme: { menuBackgroundColor },
    },
  } = table;

  const { columnOrder, columnPinning, density } = getState();

  const handleToggleAllColumns = (value?: boolean) => {
    getAllLeafColumns()
      .filter((col) => col.columnDef.enableHiding !== false)
      .forEach((col) => col.toggleVisibility(value));
  };

  const allColumns = useMemo(() => {
    const columns = getAllColumns();
    if (
      columnOrder.length > 0 &&
      !columns.some((col) => col.columnDef.columnDefType === 'group')
    ) {
      return [
        ...getLeftLeafColumns(),
        ...Array.from(new Set(columnOrder)).map((colId) =>
          getCenterLeafColumns().find((col) => col?.id === colId),
        ),
        ...getRightLeafColumns(),
      ].filter(Boolean);
    }
    return columns;
  }, [
    columnOrder,
    columnPinning,
    getAllColumns(),
    getCenterLeafColumns(),
    getLeftLeafColumns(),
    getRightLeafColumns(),
  ]) as MRT_Column<any>[];

  // const isNestedColumns = allColumns.some(
  //   (col) => col.columnDef.columnDefType === 'group',
  // );

  // console.log(`allColumns: ${JSON.stringify(allColumns)}`);

  const [hoveredColumn, setHoveredColumn] = useState<MRT_Column<any> | null>(null);

  const anchorOriginValues = { horizontal: 'left' as const, vertical: 'top' as const };
  const transformOriginValues = {
    horizontal: 'right' as const,
    vertical: 'top' as const,
  };

  return (
    <div>
      <Menu
        MenuListProps={{
          dense: density === 'compact',
          sx: {
            backgroundColor: menuBackgroundColor,
          },
        }}
        anchorEl={anchorEl}
        anchorOrigin={anchorOriginValues}
        transformOrigin={transformOriginValues}
        disableScrollLock
        onClose={onClose}
        open={!!anchorEl}
        {...rest}
      >
        <Box
          sx={{
            display: 'flex',
            justifyContent: 'space-between',
            p: '0.5rem',
            pt: 0,
          }}
        >
          {enableHiding && (
            <Button
              disabled={!getIsSomeColumnsVisible()}
              onClick={() => handleToggleAllColumns(false)}
            >
              {localization.hideAll}
            </Button>
          )}
          {enableHiding && (
            <Button
              disabled={getIsAllColumnsVisible()}
              onClick={() => handleToggleAllColumns(true)}
            >
              {localization.showAll}
            </Button>
          )}
        </Box>
        <Divider />
        {allColumns.map((column, index) => (
          // console.log(`column: ${column}`);
          // return <MRT_ShowHideColumnsMenuItems
          <MRT_ShowHideColumnsMenuItems
            allColumns={allColumns}
            column={column}
            hoveredColumn={hoveredColumn}
            isNestedColumns={false}
            key={`${index}-${column.id}`}
            setHoveredColumn={setHoveredColumn}
            table={table}
          />
        ))}
      </Menu>
    </div>
  );
};

export default ShowHideColumnsMenu;
