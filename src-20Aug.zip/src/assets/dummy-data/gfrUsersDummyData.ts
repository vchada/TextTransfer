export type GfrUsers = {
   "gea_id": string;
  "gea_name": string;
  "user_id": string;
  "is_admin": string;
  "user_name": string;
  "email": string;
  "last_modified_user": string;
  "last_modified_dt_tm": string;
  "created_user": string;
  "created_dt_tm": string;
  "site_code"?: string;
};

export const gfrUsersDummydata: GfrUsers[] = [
   {
     "gea_id": "0",
  "gea_name": "",
  "user_id": "0",
  "is_admin": "true",
  "user_name": "Venkat Chada",  
  "email": "",
  "last_modified_user": "",
  "last_modified_dt_tm": "",
  "created_user": "",
  "created_dt_tm": ""
  },
  {
     "gea_id": "5002",
  "gea_name": "",
  "user_id": "U955C6",
  "is_admin": "true",
  "user_name": "Talbot Jacob",  
  "email": "",
  "last_modified_user": "",
  "last_modified_dt_tm": "",
  "created_user": "",
  "created_dt_tm": ""
  },
  {
     "gea_id": "5003",
  "gea_name": "",
  "user_id": "U955C6",
  "is_admin": "true",
  "user_name": "Talbot Jacob",  
  "email": "",
  "last_modified_user": "",
  "last_modified_dt_tm": "",
  "created_user": "",
  "created_dt_tm": ""
  },
];
